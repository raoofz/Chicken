--
-- PostgreSQL database dump
--

\restrict 4iZ8gjccLktP9FFnMfSYd0j9yz6Y065Wntj2RYE0v01ul3hvFHDPY2jrztteG3H

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    category text DEFAULT 'other'::text NOT NULL,
    date date NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    task_id integer
);


--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: auth_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    email character varying,
    first_name character varying,
    last_name character varying,
    profile_image_url character varying,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: daily_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.daily_notes (
    id integer NOT NULL,
    content text NOT NULL,
    date date NOT NULL,
    author_id integer,
    author_name text,
    category text DEFAULT 'general'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: daily_notes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.daily_notes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: daily_notes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.daily_notes_id_seq OWNED BY public.daily_notes.id;


--
-- Name: feed_record_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feed_record_allocations (
    id integer NOT NULL,
    feed_record_id integer NOT NULL,
    flock_id integer NOT NULL,
    quantity_kg numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: feed_record_allocations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feed_record_allocations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feed_record_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feed_record_allocations_id_seq OWNED BY public.feed_record_allocations.id;


--
-- Name: feed_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feed_records (
    id integer NOT NULL,
    date date NOT NULL,
    feed_type text NOT NULL,
    brand text,
    quantity_kg numeric(10,2) NOT NULL,
    price_per_kg numeric(8,2) NOT NULL,
    total_cost numeric(12,2) NOT NULL,
    supplier text,
    transaction_id integer,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: feed_records_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.feed_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: feed_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.feed_records_id_seq OWNED BY public.feed_records.id;


--
-- Name: flock_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flock_events (
    id integer NOT NULL,
    flock_id integer NOT NULL,
    event_type text NOT NULL,
    subtype text DEFAULT ''::text NOT NULL,
    severity text DEFAULT 'medium'::text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    confidence integer DEFAULT 50 NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: flock_events_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flock_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flock_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flock_events_id_seq OWNED BY public.flock_events.id;


--
-- Name: flock_health_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flock_health_logs (
    id integer NOT NULL,
    flock_id integer NOT NULL,
    date date NOT NULL,
    status text NOT NULL,
    symptoms text,
    treatment text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: flock_health_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flock_health_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flock_health_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flock_health_logs_id_seq OWNED BY public.flock_health_logs.id;


--
-- Name: flock_production_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flock_production_logs (
    id integer NOT NULL,
    flock_id integer NOT NULL,
    date date NOT NULL,
    egg_count integer NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: flock_production_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flock_production_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flock_production_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flock_production_logs_id_seq OWNED BY public.flock_production_logs.id;


--
-- Name: flocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.flocks (
    id integer NOT NULL,
    name text NOT NULL,
    breed text NOT NULL,
    count integer NOT NULL,
    age_days integer NOT NULL,
    purpose text NOT NULL,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    birth_date date,
    health_status text DEFAULT 'healthy'::text NOT NULL,
    feed_consumption_kg numeric(8,2),
    daily_egg_target integer,
    health_score integer,
    risk_score integer,
    performance_index integer,
    last_analyzed_at timestamp without time zone
);


--
-- Name: flocks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.flocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: flocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.flocks_id_seq OWNED BY public.flocks.id;


--
-- Name: goals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.goals (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    target_value numeric(10,2) NOT NULL,
    current_value numeric(10,2) DEFAULT '0'::numeric NOT NULL,
    unit text NOT NULL,
    category text DEFAULT 'other'::text NOT NULL,
    deadline date,
    completed boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: goals_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.goals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: goals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.goals_id_seq OWNED BY public.goals.id;


--
-- Name: hatching_cycles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.hatching_cycles (
    id integer NOT NULL,
    batch_name text NOT NULL,
    eggs_set integer NOT NULL,
    eggs_hatched integer,
    start_date date NOT NULL,
    expected_hatch_date date NOT NULL,
    actual_hatch_date date,
    status text DEFAULT 'incubating'::text NOT NULL,
    temperature numeric(5,2),
    humidity numeric(5,2),
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    set_time text,
    lockdown_date date,
    lockdown_time text,
    lockdown_temperature numeric(5,2),
    lockdown_humidity numeric(5,2),
    is_active boolean DEFAULT false NOT NULL
);


--
-- Name: hatching_cycles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.hatching_cycles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: hatching_cycles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.hatching_cycles_id_seq OWNED BY public.hatching_cycles.id;


--
-- Name: note_images; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note_images (
    id integer NOT NULL,
    note_id integer,
    date text NOT NULL,
    image_url text NOT NULL,
    original_name text,
    mime_type text,
    category text DEFAULT 'general'::text NOT NULL,
    caption text,
    author_id integer,
    author_name text,
    ai_analysis text,
    ai_tags jsonb,
    ai_alerts jsonb,
    ai_confidence integer,
    analysis_status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    visual_metrics jsonb,
    risk_score integer
);


--
-- Name: note_images_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.note_images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: note_images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.note_images_id_seq OWNED BY public.note_images.id;


--
-- Name: prediction_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prediction_logs (
    id integer NOT NULL,
    engine_version text DEFAULT '2.0'::text NOT NULL,
    analysis_type text NOT NULL,
    input_hash text NOT NULL,
    predicted_hatch_rate numeric(6,3),
    predicted_risk_score integer,
    confidence_score integer,
    actual_hatch_rate numeric(6,3),
    actual_risk_materialized text,
    prediction_error numeric(6,3),
    features_snapshot jsonb,
    model_metrics jsonb,
    data_quality_score integer,
    anomalies_detected jsonb,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: prediction_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.prediction_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: prediction_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.prediction_logs_id_seq OWNED BY public.prediction_logs.id;


--
-- Name: session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sessions (
    sid character varying NOT NULL,
    sess jsonb NOT NULL,
    expire timestamp without time zone NOT NULL
);


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title text NOT NULL,
    description text,
    category text DEFAULT 'other'::text NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    due_date date,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    date date NOT NULL,
    type text NOT NULL,
    category text NOT NULL,
    description text NOT NULL,
    amount numeric(12,2) NOT NULL,
    quantity numeric(10,2),
    unit text,
    notes text,
    author_id integer,
    author_name text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    domain text
);


--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password_hash text NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'worker'::text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: daily_notes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_notes ALTER COLUMN id SET DEFAULT nextval('public.daily_notes_id_seq'::regclass);


--
-- Name: feed_record_allocations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feed_record_allocations ALTER COLUMN id SET DEFAULT nextval('public.feed_record_allocations_id_seq'::regclass);


--
-- Name: feed_records id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feed_records ALTER COLUMN id SET DEFAULT nextval('public.feed_records_id_seq'::regclass);


--
-- Name: flock_events id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flock_events ALTER COLUMN id SET DEFAULT nextval('public.flock_events_id_seq'::regclass);


--
-- Name: flock_health_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flock_health_logs ALTER COLUMN id SET DEFAULT nextval('public.flock_health_logs_id_seq'::regclass);


--
-- Name: flock_production_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flock_production_logs ALTER COLUMN id SET DEFAULT nextval('public.flock_production_logs_id_seq'::regclass);


--
-- Name: flocks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flocks ALTER COLUMN id SET DEFAULT nextval('public.flocks_id_seq'::regclass);


--
-- Name: goals id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goals ALTER COLUMN id SET DEFAULT nextval('public.goals_id_seq'::regclass);


--
-- Name: hatching_cycles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hatching_cycles ALTER COLUMN id SET DEFAULT nextval('public.hatching_cycles_id_seq'::regclass);


--
-- Name: note_images id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_images ALTER COLUMN id SET DEFAULT nextval('public.note_images_id_seq'::regclass);


--
-- Name: prediction_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs ALTER COLUMN id SET DEFAULT nextval('public.prediction_logs_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.activity_logs (id, title, description, category, date, created_at, task_id) FROM stdin;
1	اضافه دبس و3 لتر ماء اليوم ك فيتامينات	اضافه دبس و3 لتر ماء اليوم ك فيتامينات / هوبي	observation	2026-04-15	2026-04-15 23:53:35.58023	\N
2	هوبي الصباح تنظيف وفحص الصيصان بالحواضن	هوبي نظف المكان وفحص الصيصان والامور تمام	cleaning	2026-04-16	2026-04-16 11:13:15.37845	\N
\.


--
-- Data for Name: auth_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_users (id, email, first_name, last_name, profile_image_url, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: daily_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.daily_notes (id, content, date, author_id, author_name, category, created_at) FROM stdin;
1	اعطاء الصواصي خلطه دبس وخمره ، واربعه لتر ماء\nهوبي الصباح	2026-04-15	4	رؤوف	health	2026-04-15 23:14:20.127288
6	تم اضافه بيض عدد ١٠٤ بيض جديد درجه اولى ، \nاليوم الساعه ٤ عصرا تم فتح الماكينه واضافتهم ، كان بداخلها ٩٠ بيضه من مبارح	2026-04-16	4	رؤوف	general	2026-04-16 18:01:18.158264
7	اليوم قررنا اضافه ماكينه لفحص البيض الملقح من الدوره القادمه	2026-04-16	\N	raoof	health	2026-04-16 20:48:11.216519
8	اختبار ملاحظة من مركز العمليات	2026-04-16	3	يونس	general	2026-04-16 23:27:47.172355
\.


--
-- Data for Name: feed_record_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feed_record_allocations (id, feed_record_id, flock_id, quantity_kg, created_at) FROM stdin;
\.


--
-- Data for Name: feed_records; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feed_records (id, date, feed_type, brand, quantity_kg, price_per_kg, total_cost, supplier, transaction_id, notes, created_at) FROM stdin;
1	2026-04-16	layer	Golden	50.00	800.00	40000.00	المورد الرئيسي	\N	شوال علف دجاج بياض	2026-04-16 22:31:50.550747
\.


--
-- Data for Name: flock_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flock_events (id, flock_id, event_type, subtype, severity, payload, confidence, created_at) FROM stdin;
1	6	analysis	full_intelligence	low	{"riskScore": 15, "healthScore": 100, "anomalyCount": 1, "performanceIndex": 20}	17	2026-04-17 00:47:37.179938
2	6	mortality	confirmed_death	high	{"text": "مات 3 دجاج اليوم والباقي خامل", "value": 3, "signalAr": "نفوق 3 طائر"}	90	2026-04-17 00:48:15.580187
3	6	health_change	lethargy	medium	{"text": "مات 3 دجاج اليوم والباقي خامل", "signalAr": "خمول وضعف"}	85	2026-04-17 00:48:15.614945
4	4	mortality	confirmed_death	high	{"text": "مات 3 دجاج اليوم والباقي خامل ولا يأكل", "value": 3, "signalAr": "نفوق 3 طائر"}	90	2026-04-17 00:49:59.24481
5	4	health_change	not_eating	high	{"text": "مات 3 دجاج اليوم والباقي خامل ولا يأكل", "signalAr": "رفض الأكل"}	85	2026-04-17 00:49:59.248431
6	4	health_change	lethargy	medium	{"text": "مات 3 دجاج اليوم والباقي خامل ولا يأكل", "signalAr": "خمول وضعف"}	85	2026-04-17 00:49:59.251216
7	4	analysis	full_intelligence	high	{"riskScore": 55, "healthScore": 60, "anomalyCount": 2, "performanceIndex": 20}	10	2026-04-17 00:50:10.325165
8	6	analysis	full_intelligence	low	{"riskScore": 27, "healthScore": 90, "anomalyCount": 1, "performanceIndex": 20}	17	2026-04-17 01:09:09.56756
\.


--
-- Data for Name: flock_health_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flock_health_logs (id, flock_id, date, status, symptoms, treatment, notes, created_at) FROM stdin;
1	6	2026-04-16	healthy	صحه سليمه	صحه سليمه	تم فحصهم وكلهم سليمات	2026-04-16 22:12:18.654308
\.


--
-- Data for Name: flock_production_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flock_production_logs (id, flock_id, date, egg_count, notes, created_at) FROM stdin;
\.


--
-- Data for Name: flocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.flocks (id, name, breed, count, age_days, purpose, notes, created_at, birth_date, health_status, feed_consumption_kg, daily_egg_target, health_score, risk_score, performance_index, last_analyzed_at) FROM stdin;
5	دفعة مارس — الفقسة الثالثة	بلدي	110	29	eggs	فقست في 18 مارس 2026 — 110 فرخ من 208 بيضة (52.9٪) — الفقسة الثالثة	2026-04-16 00:41:50.084739	2026-03-18	healthy	\N	\N	\N	\N	\N	\N
4	دفعة فبراير — الفقسة الثانية	بلدي	10	51	eggs	فقست في 24 فبراير 2026 — 10 فراخ من 80 بيضة (12.5٪) — الفقسة الثانية	2026-04-16 00:41:50.084739	2026-02-24	healthy	\N	\N	60	55	20	2026-04-17 00:50:10.321828
6	دفعة أبريل — الفقسة الرابعة	بلدي	189	7	eggs	فقست في 10 أبريل 2026 — 189 فرخ من 405 بيضة (46.7٪) — الفقسة الرابعة	2026-04-16 00:41:50.084739	2026-04-10	healthy	\N	\N	90	27	20	2026-04-17 01:09:09.564452
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.goals (id, title, description, target_value, current_value, unit, category, deadline, completed, created_at) FROM stdin;
2	زيادة الإنتاج	الوصول لـ ٥٠٠ كتكوت شهرياً	500.00	190.00	كتكوت	production	2026-06-14	f	2026-04-15 20:17:01.663203
1	زيادة نسبة التفقيس	الوصول لنسبة تفقيس أعلى من ٨٥٪ في كل دورة	85.00	37.00	%	hatching	2026-07-14	f	2026-04-15 20:17:01.663203
4	شراء ماكينه علف الشهر القادم		100.00	0.00	علف	financial	\N	f	2026-04-16 23:02:08.475199
\.


--
-- Data for Name: hatching_cycles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.hatching_cycles (id, batch_name, eggs_set, eggs_hatched, start_date, expected_hatch_date, actual_hatch_date, status, temperature, humidity, notes, created_at, set_time, lockdown_date, lockdown_time, lockdown_temperature, lockdown_humidity, is_active) FROM stdin;
2	الفقسة الأولى	68	0	2026-01-12	2026-02-02	2026-02-02	completed	37.50	55.00	فشل كامل — 0 فرخ من 68 بيضة (0٪). السبب: عدم تشغيل التقليب + خلل في الرطوبة. الدرس: التقليب شرط أساسي لنجاح الفقس.	2026-04-16 00:41:29.789347	22:30	\N	\N	\N	\N	f
5	الفقسة الرابعة	405	189	2026-03-20	2026-04-10	2026-04-10	completed	37.50	55.00	انخفاض بسيط مقارنة بالفقسة السابقة — 189 فرخ من 405 بيضة (46.7٪). احتمال: جودة البيض أقل أو رطوبة/حرارة غير مستقرة أو نسبة تخصيب أقل.	2026-04-16 00:41:29.789347	08:00	2026-05-04	21:40	\N	\N	f
4	الفقسة الثالثة	208	110	2026-02-25	2026-03-18	2026-03-18	completed	37.50	55.00	تحسن كبير في الإدارة — 110 فرخ من 208 بيضة (52.9٪). التقليب ممتاز، الرطوبة أفضل، لكن ما زالت تحتاج ضبط للوصول إلى 80٪.	2026-04-16 00:41:29.789347	23:00	2026-05-04	21:40	\N	\N	f
3	الفقسة الثانية	80	10	2026-02-03	2026-02-24	2026-02-24	completed	37.50	55.00	تحسن في التقليب لكن الرطوبة غير مستقرة — 10 فراخ من 80 بيضة (12.5٪). بداية تحسن لكن الرطوبة ما زالت غير دقيقة.	2026-04-16 00:41:29.789347	17:41	2026-05-04	\N	\N	\N	f
6	الدفعه الخامسه	194	\N	2026-04-15	2026-05-07	\N	incubating	37.70	55.00		2026-04-16 18:00:14.613446	20:00	2026-05-04	\N	\N	\N	t
\.


--
-- Data for Name: note_images; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note_images (id, note_id, date, image_url, original_name, mime_type, category, caption, author_id, author_name, ai_analysis, ai_tags, ai_alerts, ai_confidence, analysis_status, created_at, visual_metrics, risk_score) FROM stdin;
\.


--
-- Data for Name: prediction_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prediction_logs (id, engine_version, analysis_type, input_hash, predicted_hatch_rate, predicted_risk_score, confidence_score, actual_hatch_rate, actual_risk_materialized, prediction_error, features_snapshot, model_metrics, data_quality_score, anomalies_detected, resolved_at, created_at) FROM stdin;
1	brain-orchestrator-1.0	full_orchestration	bb866f17e1a72ef0	73.110	32	71	\N	\N	\N	{"sickFlocks": 0, "totalBirds": 409, "activeCycles": 1, "avgHatchRate": 28, "overdueTasks": 0, "completedCycles": 4}	{"r2": 0.8168, "autocorr": 0.2574, "olsSlope": 18.0385, "ewmaSlope": 9.557, "sampleSize": 4, "anomalyCount": 0, "changePointCount": 0}	100	[]	\N	2026-04-16 22:09:12.473993
2	brain-orchestrator-1.0	full_orchestration	bb866f17e1a72ef0	73.110	32	71	\N	\N	\N	{"sickFlocks": 0, "totalBirds": 409, "activeCycles": 1, "avgHatchRate": 28, "overdueTasks": 0, "completedCycles": 4}	{"r2": 0.8168, "autocorr": 0.2574, "olsSlope": 18.0385, "ewmaSlope": 9.557, "sampleSize": 4, "anomalyCount": 0, "changePointCount": 0}	100	[]	\N	2026-04-16 22:09:18.000472
3	brain-orchestrator-1.0	full_orchestration	e37993e1218eb1cf	73.110	32	71	\N	\N	\N	{"sickFlocks": 0, "totalBirds": 409, "activeCycles": 1, "avgHatchRate": 28, "overdueTasks": 0, "completedCycles": 4}	{"r2": 0.8168, "autocorr": 0.2574, "olsSlope": 18.0385, "ewmaSlope": 9.557, "sampleSize": 4, "anomalyCount": 0, "changePointCount": 0}	100	[]	\N	2026-04-16 22:31:47.138195
4	brain-orchestrator-1.0	full_orchestration	e37993e1218eb1cf	73.110	32	71	\N	\N	\N	{"sickFlocks": 0, "totalBirds": 409, "activeCycles": 1, "avgHatchRate": 28, "overdueTasks": 0, "completedCycles": 4}	{"r2": 0.8168, "autocorr": 0.2574, "olsSlope": 18.0385, "ewmaSlope": 9.557, "sampleSize": 4, "anomalyCount": 0, "changePointCount": 0}	100	[]	\N	2026-04-16 22:34:25.445903
5	brain-orchestrator-1.0	full_orchestration	e37993e1218eb1cf	73.110	32	71	\N	\N	\N	{"sickFlocks": 0, "totalBirds": 409, "activeCycles": 1, "avgHatchRate": 28, "overdueTasks": 0, "completedCycles": 4}	{"r2": 0.8168, "autocorr": 0.2574, "olsSlope": 18.0385, "ewmaSlope": 9.557, "sampleSize": 4, "anomalyCount": 0, "changePointCount": 0}	100	[]	\N	2026-04-16 22:37:07.181321
6	brain-orchestrator-1.0	full_orchestration	e37993e1218eb1cf	73.110	32	71	\N	\N	\N	{"sickFlocks": 0, "totalBirds": 409, "activeCycles": 1, "avgHatchRate": 28, "overdueTasks": 0, "completedCycles": 4}	{"r2": 0.8168, "autocorr": 0.2574, "olsSlope": 18.0385, "ewmaSlope": 9.557, "sampleSize": 4, "anomalyCount": 0, "changePointCount": 0}	100	[]	\N	2026-04-16 22:39:01.269705
\.


--
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.session (sid, sess, expire) FROM stdin;
y__MlncVhpNtpBWwNxqsQYns1OsaWoJn	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:09:12.310Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:09:13
bqYMCXfE4Mjq2TA4pm_6dYwQZNhEAJNU	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:55:43.653Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:55:44
6uhqidxUgENxtzklDUByjscoDcSWDqlr	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:31:46.995Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:32:31
-9jQELuwhogXcLvTPLeDvT3FuPtGsDk3	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T20:56:05.243Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 20:56:31
FcZh13wxACoTsGwdhG87SpLMVVItW64V	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T21:26:28.848Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 21:27:26
GnyYZOqdftXH6UGrUTyfUZNHdLW6LGY4	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-24T00:49:55.092Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":4,"role":"admin","name":"رؤوف"}	2026-04-24 00:49:56
6aOl_qQPghEEPcRAkJ7_DA6npZATJsBm	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:55:49.864Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:56:04
VsKLQ9MqlIVageRnuuO8gX0Qw4K7-0MW	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:19:34.302Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:19:45
7YpT4dETcLHZoPNwQgURVbpBMTM0aI9Z	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T21:50:49.451Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 21:52:17
2PlJwt2kazmgNaAFWHvi4er_fQPDkECV	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:27:59.849Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:28:02
b805qvW49_cOllanUWnObanfcVeEEqIF	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T21:49:53.990Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":5,"role":"admin","name":"نصار"}	2026-04-23 21:54:21
tDXiPTD51GaxNV6UGJhB7cJGB3VB-NQA	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-24T00:47:13.522Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":4,"role":"admin","name":"رؤوف"}	2026-04-24 00:48:22
YquO28DfD0C5tE46kXK0-V2cMEOr8JA-	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T21:07:46.713Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 21:07:48
A_-lGjRPSTzQMfPyy50n0ZiTwh5ADURp	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:34:25.283Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:34:26
7tm9zqk4NlGcAAACUdgdM4OWeTtm0Aqz	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-24T00:06:13.190Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-24 00:06:38
E3bj4fQ6Cgy96d7bBBCydbk6ZpnjHXcZ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T21:46:55.393Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 21:48:34
hyC3X3fEmwJW532qMzZPcvvVUaCoLJND	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:37:07.018Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:37:08
4lcStYV_cDn9FkmJU_a624ox8-K5oqAB	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:00:10.970Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:00:35
LDrZt_J58nak8drkxQET7TBD_3s--1MY	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T21:02:52.787Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":4,"role":"admin","name":"رؤوف"}	2026-04-23 23:02:19
L7I3gMeEJGMyjHuetbsO3xvpB6MagTwO	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:57:21.173Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:58:20
N4M6GG8iLhvLcfp2K708K-xCnmVaak8N	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:39:01.062Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:39:02
7WjcGNH1HCuLPagDc4t99dyqM5aaLGo1	{"cookie":{"originalMaxAge":604799999,"expires":"2026-04-23T20:59:48.046Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":4,"role":"admin","name":"رؤوف"}	2026-04-23 23:03:22
YMRIlMgQir20aCEhEFmUOaiNAFChcYhr	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:48:49.321Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:48:50
1Fu7fxoMnspr4a5xUVww9PZmQiPcB_EM	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T22:55:37.076Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 22:55:38
ZtO-ffY2SAukCQP2zZDbQTwEXcbD539E	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-23T23:27:03.260Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":3,"role":"admin","name":"يونس"}	2026-04-23 23:27:48
iTbKxYKsXOLYji8Rg3IQSRjbD7XpoIyQ	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-24T00:49:59.137Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":4,"role":"admin","name":"رؤوف"}	2026-04-24 00:50:11
DPVw4tUhGI2SMfWefL4xU8CjI5JntSxd	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-24T00:59:01.460Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":4,"role":"admin","name":"رؤوف"}	2026-04-24 01:05:32
C6w8FVybmyBGfPsHO80pblpudgUkHh8F	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-24T01:06:39.687Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":4,"role":"admin","name":"رؤوف"}	2026-04-24 01:07:29
UMVJcL_RN1wk6TNLG3FUMchcJOahKmlG	{"cookie":{"originalMaxAge":604800000,"expires":"2026-04-24T00:08:16.188Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"userId":4,"role":"admin","name":"رؤوف"}	2026-04-24 01:13:18
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sessions (sid, sess, expire) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tasks (id, title, description, category, priority, completed, due_date, created_at) FROM stdin;
1	البحث عن بيض غدا جديد واضافته للماكينه ان وجد الصباح 	البحث عن بيض غدا جديد واضافته للماكينه ان وجد الصباح . مسموح فتح الماكينه لمده دقيقه فقط ووضع البيض الجديد ان وجد	feeding	high	t	2026-04-16	2026-04-16 00:04:23.085558
2	اضافه بيض للفقاسه	تم اضافه بيض للفقاسه اليوم ١٩٤	hatching	high	t	2026-04-16	2026-04-16 18:00:51.442485
3	تغذيه جميع الصيصان والدجاجات وفحصهم	تغذيه جميع الصيصان والدجاجات وفحصهم	health	high	t	2026-04-16	2026-04-16 19:04:14.192385
4	تنظيف غرفه الماكينه وحاضنات الصيصان		health	high	t	2026-04-16	2026-04-16 19:04:45.73669
5	مراجعه الرطوبه والحراره والتاكد منهم	مراجعه الرطوبه والحراره والتاكد منهم	hatching	high	t	2026-04-16	2026-04-16 19:05:17.076845
6	اليوم قررنا اضافه ماكينه لفحص البيض الملقح من الدوره القادمه	اليوم قررنا اضافه ماكينه لفحص البيض الملقح من الدوره القادمه	health	medium	f	2026-04-17	2026-04-16 20:48:11.216519
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, date, type, category, description, amount, quantity, unit, notes, author_id, author_name, created_at, domain) FROM stdin;
1	2026-04-15	expense	other	بيض	30000.00	90.00	\N	تم وضعهم بالمفقسه مباسره وتشغيلها ب ٩٠ بيضه ، 	4	raoof	2026-04-15 20:23:26.031673	\N
4	2026-04-16	expense	feed	شوال علف	40000.00	50.00	كيلو	\N	4	raoof	2026-04-16 18:02:42.817136	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password_hash, name, role, created_at) FROM stdin;
3	yones	$2b$10$//yn/jQ6.MraUx1Rne9kn.bMiZBBWN5cm.jNxndnX.GLMHdj1LQDy	يونس	admin	2026-04-11 03:12:10.513016
6	hoobi	$2b$10$bD2bu3iI2SQ4MSxWoIu4nO2nG5FxyfermpJYZneaaORCMfaxfL6DK	هوبي	worker	2026-04-11 03:12:10.79429
7	abood	$2b$10$ThzMS3iUlxOVWVbuVSzbIeTkvotjnm2hHiMBAYRcKf4obroDeih/u	عبود	worker	2026-04-11 03:12:10.879098
5	nassar	$2b$10$2hqFTd53MWEdT2.ucQWebubEMT3g3UglqJUH9m5Y25g.4mRvf7fpe	نصار	admin	2026-04-11 03:12:10.711937
4	raoof	$2b$10$ANpj1jI2J5VQXUn80iaFK.cOKOSU.rkFcjFCrkNXyQi9zpngLqGYa	رؤوف	admin	2026-04-11 03:12:10.624413
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 2, true);


--
-- Name: daily_notes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.daily_notes_id_seq', 8, true);


--
-- Name: feed_record_allocations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.feed_record_allocations_id_seq', 1, false);


--
-- Name: feed_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.feed_records_id_seq', 1, true);


--
-- Name: flock_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.flock_events_id_seq', 8, true);


--
-- Name: flock_health_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.flock_health_logs_id_seq', 1, true);


--
-- Name: flock_production_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.flock_production_logs_id_seq', 2, true);


--
-- Name: flocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.flocks_id_seq', 8, true);


--
-- Name: goals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.goals_id_seq', 4, true);


--
-- Name: hatching_cycles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.hatching_cycles_id_seq', 6, true);


--
-- Name: note_images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.note_images_id_seq', 1, false);


--
-- Name: prediction_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.prediction_logs_id_seq', 38, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tasks_id_seq', 7, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_id_seq', 1004, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_users auth_users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT auth_users_email_unique UNIQUE (email);


--
-- Name: auth_users auth_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_users
    ADD CONSTRAINT auth_users_pkey PRIMARY KEY (id);


--
-- Name: daily_notes daily_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.daily_notes
    ADD CONSTRAINT daily_notes_pkey PRIMARY KEY (id);


--
-- Name: feed_record_allocations feed_record_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feed_record_allocations
    ADD CONSTRAINT feed_record_allocations_pkey PRIMARY KEY (id);


--
-- Name: feed_records feed_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feed_records
    ADD CONSTRAINT feed_records_pkey PRIMARY KEY (id);


--
-- Name: flock_events flock_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flock_events
    ADD CONSTRAINT flock_events_pkey PRIMARY KEY (id);


--
-- Name: flock_health_logs flock_health_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flock_health_logs
    ADD CONSTRAINT flock_health_logs_pkey PRIMARY KEY (id);


--
-- Name: flock_production_logs flock_production_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flock_production_logs
    ADD CONSTRAINT flock_production_logs_pkey PRIMARY KEY (id);


--
-- Name: flocks flocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flocks
    ADD CONSTRAINT flocks_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: hatching_cycles hatching_cycles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.hatching_cycles
    ADD CONSTRAINT hatching_cycles_pkey PRIMARY KEY (id);


--
-- Name: note_images note_images_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note_images
    ADD CONSTRAINT note_images_pkey PRIMARY KEY (id);


--
-- Name: prediction_logs prediction_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prediction_logs
    ADD CONSTRAINT prediction_logs_pkey PRIMARY KEY (id);


--
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_session_expire" ON public.sessions USING btree (expire);


--
-- Name: idx_flock_events_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_flock_events_created_at ON public.flock_events USING btree (created_at DESC);


--
-- Name: idx_flock_events_flock_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_flock_events_flock_id ON public.flock_events USING btree (flock_id);


--
-- Name: idx_flock_health_logs_flock_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_flock_health_logs_flock_id ON public.flock_health_logs USING btree (flock_id);


--
-- Name: idx_flock_production_logs_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_flock_production_logs_date ON public.flock_production_logs USING btree (date);


--
-- Name: idx_flock_production_logs_flock_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_flock_production_logs_flock_id ON public.flock_production_logs USING btree (flock_id);


--
-- Name: feed_record_allocations feed_record_allocations_feed_record_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feed_record_allocations
    ADD CONSTRAINT feed_record_allocations_feed_record_id_fkey FOREIGN KEY (feed_record_id) REFERENCES public.feed_records(id) ON DELETE CASCADE;


--
-- Name: feed_record_allocations feed_record_allocations_flock_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feed_record_allocations
    ADD CONSTRAINT feed_record_allocations_flock_id_fkey FOREIGN KEY (flock_id) REFERENCES public.flocks(id) ON DELETE CASCADE;


--
-- Name: flock_health_logs flock_health_logs_flock_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flock_health_logs
    ADD CONSTRAINT flock_health_logs_flock_id_fkey FOREIGN KEY (flock_id) REFERENCES public.flocks(id) ON DELETE CASCADE;


--
-- Name: flock_production_logs flock_production_logs_flock_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.flock_production_logs
    ADD CONSTRAINT flock_production_logs_flock_id_fkey FOREIGN KEY (flock_id) REFERENCES public.flocks(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 4iZ8gjccLktP9FFnMfSYd0j9yz6Y065Wntj2RYE0v01ul3hvFHDPY2jrztteG3H

