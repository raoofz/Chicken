# Workspace — مدير المزرعة (Poultry Farm Manager)

## Overview

This project is a full-stack poultry farm management system designed to optimize farm operations and boost profitability. It features two distinct web frontends (Arabic and Swedish) that share a single API backend, all managed within a pnpm workspace monorepo. The system aims to provide comprehensive financial and production intelligence, leveraging advanced analytics, AI-powered insights, and computer vision for enhanced decision-making. Key capabilities include real-time financial tracking, anomaly detection, predictive forecasting, intelligent task management, and detailed performance analysis, ultimately aiming to improve farm efficiency and financial outcomes.

## User Preferences

I prefer iterative development, where we focus on one feature or module at a time. Please ask for my approval before making any major architectural changes or implementing new features. I value clear, concise explanations and prefer to be involved in key design decisions.

## System Architecture

The system is structured as a pnpm monorepo, facilitating shared code and consistent development across multiple applications.

**UI/UX Decisions:**
- **Localizations:** Separate Arabic (RTL) and Swedish (LTR) web applications (`artifacts/poultry-manager` and `artifacts/poultry-manager-sv`).
- **Typography:** Arabic uses Tajawal/Cairo fonts; Swedish uses Inter font.
- **Color Scheme:** A warm earthy palette (primary: `#B85C2A`, background: `#F7F0E6`, sidebar: `#1A1208`) is consistently applied across both frontends.
- **Component Library:** Both frontends utilize `shadcn/ui` for responsive and consistent componentry.
- **Role-based Access:** Features and navigation are access-controlled based on user roles (e.g., `admin`, `worker`).

**Technical Implementations:**
- **Frontend:** React with Vite.
- **Backend:** Express 5.
- **Monorepo Management:** pnpm workspaces.
- **Language & Type Checking:** TypeScript 5.9.
- **Build Tool:** esbuild (CJS bundle).
- **API Generation:** Orval for generating API hooks and Zod schemas from an OpenAPI specification (`lib/api-spec/openapi.yaml`).
- **Authentication:** Session-based with bcrypt-hashed credentials and PostgreSQL for session storage. Supports `admin` and `worker` roles.
- **Security:** Helmet for headers, rate limiting, CORS for all origins, secure httpOnly/sameSite session cookies, Zod for input validation, parameterized queries via Drizzle ORM, and audit logging.
- **Multi-language Support:** Full localization for Arabic and Swedish across frontends and reports.

**Feature Specifications & System Design Choices:**
- **Finance & Production Intelligence:** Real-time data polling, a 7-rule deterministic anomaly detection engine, cost intelligence metrics (cost per bird/day, profit per bird, ROI%), and a linear regression-based predictive engine for financial forecasting. Includes various UI components for data visualization and reporting.
- **Intelligence System:** A context-aware 7-point analysis using a `Context Engine` to aggregate daily farm data into `DaySnapshot` objects and an `Intelligence Engine` to generate localized reports covering current state, historical comparison, root causes, risks, and recommended actions.
- **Computer Vision AI System:** A 3-layer architecture (Vision, Intelligence, Decision) for analyzing farm images. The Vision Layer performs pixel-level analysis for metrics like density, activity, and injury risk. The Intelligence Layer uses a rules-based engine for anomaly detection and risk scoring. The Decision Layer generates prioritized recommendations and alerts. Stores `visual_metrics` as JSONB.
- **Daily Notes:** A text journal with categories, featuring an AI parser that extracts transactions, hatching cycles, flocks, and tasks from free-text entries in Arabic/Swedish.
- **AI Analysis (Admin-only):** Provides multi-dimensional scoring, statistical anomaly detection, trend analysis, predictive analytics, actionable recommendations, disease keyword detection, and a chat mode for expert replies.
- **Daily Plan (Admin-only):** AI-generated daily schedules, dynamic task slots, risk indicators, and daily tips with an interactive checklist.
- **Data Models:** PostgreSQL database schema includes tables for `flocks`, `tasks`, `hatching_cycles`, `goals`, `users`, `daily_notes`, and `activity_logs`, with appropriate indexing.
- **Smart Input Pipeline:** A WhatsApp-style chat interface (`/smart-input`) for workers to input daily activities. The backend processes these inputs through a parse-review-confirm-commit pipeline, ensuring server-side validation and atomic database transactions. Includes a strict `actionValidator` for range checks, duplicate detection, and logic checks, with bilingual error messages.
- **Farm Domains (SSOT):** A central `farmDomains.ts` module defines all transaction categories, domain partitions (e.g., `feed`, `egg`, `health`), bilingual labels, and classification logic. Ensures consistency across transaction processing and AI parsing.
- **DB Schema Updates:** `transactions` table includes a `domain` column auto-populated from `farmDomains`. `activity_logs` table includes a `task_id` FK, linking activities to tasks and automatically marking tasks as completed.
- **Egg Classification Fix:** Rewritten `noteSmartParser.ts` to use `farmDomains` SSOT, correctly prioritizing egg purchase classification over hatching cycle detection to prevent misclassification.
- **Real-Time Incubation Live Tracker:** A component in `pages/hatching.tsx` that displays the progress of incubation cycles in real-time with phase-specific coloring and markers.
- **Daily Operations Center (`/operations`):** A new page with tabs for Overview, Tasks, and Activity Log. Features KPI strips, overdue task alerts, smart task-activity linking (auto-completes tasks when linked activities are created), and immediate task completion toggles.
- **Activity Logs/Transactions Route Enhancements:** Routes updated to accept `taskId` for activity logs, auto-complete linked tasks, support DELETE, and auto-populate/validate the `domain` column for transactions based on `farmDomains`.
- **Feed Cost Intelligence Engine (`/feed`):** Enterprise-grade feed analytics system with: `feed_records` + `feed_record_allocations` DB tables, `breed-benchmarks.ts` (FCR/production curves for 5 breeds), `feed-cost-engine.ts` (per-flock FCR vs benchmark, cost-per-egg, efficiency score 0-100), 5 API routes (`/api/feed-intelligence/*`), and a full dashboard page (`feed-intelligence.tsx`) with ScoreGauge, cost-per-flock bar chart, per-flock deep-dive, and breed benchmark table. Radar chart and redundant efficiency-score bars removed for clarity.
- **Brain Orchestrator Feed Integration:** The Brain Orchestrator (`/brain/analyze`) now runs `runFeedCostEngine` in parallel with all other engines, contributing feed-specific insights (efficiency score, cost ratio, per-flock warnings, missing-records alert) to the unified decision output.
- **Operations Center Consolidated (`/operations`):** The `/notes` page is no longer a separate nav item. Daily Notes are now embedded as a 5th tab ("الملاحظات") inside the Operations Center alongside Overview, Tasks, Activity Log, and System tabs. The notes tab supports adding notes with AI smart-analyze extraction, color-coded categories, and delete. The KPI strip now shows 4 cards (tasks, overdue, today's activities, total notes). The "ملاحظة جديدة" button is always visible in the header.

## Chickens AI Intelligence Engine (Module 15-21)

An isolated, additive intelligence layer exclusively for the Chickens/Flocks module. Does NOT modify any other module.

### Backend Engine (`artifacts/api-server/src/lib/chickens-ai-engine/index.ts`)
Seven integrated sub-engines:
1. **Semantic Parser** — Arabic NLP: detects mortality counts, health signals (bad/good), behavioral signals, interventions, environmental factors from free Arabic text
2. **Confidence Engine** — scores data coverage 0-100 based on production logs, health history, feed data, recency. < 60 → clarification question; > 80 → auto-suggest
3. **Health Engine** — computes `health_score` (100 minus penalties for mortality, sick status, production gaps), `risk_score` (sum of mortality rate risk, health status risk, age risk), `performance_index` (production vs target ratio)
4. **Anomaly Engine** — detects: mortality spikes (>2% or >5%), production drops (>40% decline), recurring health deterioration, missing production data
5. **Decision Engine** — generates prioritized actions: P1=critical/now, P2=important/today, P3=monitoring/this_week, each with confidence score
6. **Predictive Engine** — forecasts mortality risk (24h/48h) and production decline (7d) based on trends and health status
7. **Timeline Manager** — persists structured events to `flock_events` table; updates `health_score`, `risk_score`, `performance_index`, `last_analyzed_at` in `flocks` table

### API Routes (`artifacts/api-server/src/routes/flock-intelligence.ts`)
- `POST /api/flocks/:id/intelligence/analyze` — full analysis, returns all 7 engine outputs
- `POST /api/flocks/:id/intelligence/parse-note` — parse Arabic text, return events + confidence, save to timeline
- `GET /api/flocks/:id/intelligence/timeline` — event history (last 30)

### DB Additions (via migrate.ts Fix 5 + Fix 6)
- New table: `flock_events` (id, flock_id, event_type, subtype, severity, payload JSONB, confidence, created_at)
- New columns on `flocks`: `health_score`, `risk_score`, `performance_index`, `last_analyzed_at`

### Frontend (`artifacts/poultry-manager/src/components/FlockIntelligencePanel.tsx`)
5th tab "🧠 ذكاء" in flock detail modal. Shows:
- Health / Risk / Performance score gauges (SVG arc)
- Confidence meter with threshold behavior + clarification request
- Anomaly cards (color-coded by severity)
- Expandable decisions list (P1 red, P2 orange, P3 blue)
- Predictions with probability bars
- Smart Arabic note parser (live events + confidence from free text)
- Event timeline (collapsible, last 20 events)

## Security & Production Hardening

- **Session Secret**: `SESSION_SECRET` env var required; app exits in production if missing. Dev fallback logs a warning.
- **Seed Passwords**: Hardcoded "1234" removed. Now uses `ADMIN_PASSWORD` / `WORKER_PASSWORD` env vars with dev fallbacks that log warnings. Production refuses to seed with weak/missing passwords.
- **Password Min Length**: Changed from 4 to 8 characters in `change-password` route.
- **bcrypt Salt Rounds**: 12 (increased from 10) for new seeds.
- **fuser -k**: Removed. Port-in-use now fails fast with a clear error message.
- **RBAC**: `requireAuth` + `requireRole("admin")` exported from `routes/index.ts`. Admin checks added inline to `/validate/integrity`, `/dev/seed-transactions`, `/dev/seed-transactions DELETE`.
- **Helmet CSP**: Enabled in production with strict directives; disabled only in development.
- **CORS**: Configurable via `ALLOWED_ORIGINS` env var (comma-separated); falls back to `true` in development for Replit proxy.
- **Error responses**: All error responses include `success: false` field. No stack traces ever exposed.
- **`.gitignore`**: Added `.env`, `*.sql`, `backups/`, `downloads/`, `uploads/`, `*.log`, `*.pem/key/crt` patterns.
- **README.md**: Professional documentation with architecture diagram, security model, env vars reference, deployment guide, and API table.

## External Dependencies

- **Database:** PostgreSQL (with Drizzle ORM).
- **AI Integrations:** OpenAI GPT-4o-mini Vision (via Replit AI Integrations proxy).
- **Object Storage:** Google Cloud Storage (via Replit sidecar proxy for farm photos).
- **Weather API:** Open-Meteo (for live weather data in decision logic).